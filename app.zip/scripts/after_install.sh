#!/bin/bash
cd /home/ubuntu/hit-tracking-service
rm -rf .env
git checkout dev
git pull
cp -r /opt/hit-env/.env /home/ubuntu/hit-tracking-service