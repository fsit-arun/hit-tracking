#!/bin/bash
cd /home/ubuntu/hit-tracking-service
npm start