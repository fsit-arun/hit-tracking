#!/bin/bash
node_port=$(netstat -lntp | grep 3001 | awk '{ print $7 }' | cut -d '/' -f1)
kill -9 $node_port